//Number of population samples (demes)
1
//Population effective sizes (number of genes)
NCUR
//Sample sizes
14
//Growth rates : negative growth implies population expansion
0
//Number of migration matrices : 0 implies no migration between demes
0
//historical event: time, source, sink, migrants, new size, new growth rate, migr. matrix
2 historical event
TENL 0 0 0 RESENL 0 0
TANC 0 0 0 RESANC 0 0
//Number of independent loci [chromosome]
1 0
//Per chromosome: Number of linkage blocks
1
//per Block: data type, num loci, rec. rate and mut rate + optional parameters
FREQ 1 0 7.7e-9 OUTEXP